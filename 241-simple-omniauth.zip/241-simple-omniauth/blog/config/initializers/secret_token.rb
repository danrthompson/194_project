# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Blog::Application.config.secret_token = '1376012fdef8bb7960e9c4e5a0ec7f18bf54e134d2142eda38bf2687690158c98fa13eea028fbf65ee3e9159dfd9bf106d5b1c90227a00c370d9bc426bd8350a'
